Hello!

Welcome to my solitaire game!

Some things that I changed from my last implementation

- added a mock class that handles a log that makes moves
- updated my view to improve spacing
- updated my is card visible method to improve printing of "invisible" cards
- wrote a controller class that now takes in cases and moves cards accordingly
- added more tests for the controller and view