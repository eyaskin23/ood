package cs3500.klondike.view;

/** A marker interface for all text-based views, to be used in the Klondike game. */
public interface TextualView {

  String render();
}
