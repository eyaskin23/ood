package cs3500.klondike.view;

import java.util.List;

import cs3500.klondike.model.hw02.Card;
import cs3500.klondike.model.hw02.KlondikeModel;


/**
 * A simple text-based rendering of the Klondike game.
 */
public class KlondikeTextualView implements TextualView {
  private final KlondikeModel basic;

  /**
   * Creates a new klondike textual view.
   */
  public KlondikeTextualView(KlondikeModel basic) {
    if (basic == null) {
      throw new IllegalArgumentException("Model cannot be null.");
    }
    this.basic = basic;
  }

  /**
   * Returns the solitaire game as a string
   * in the format given by the assignment.
   */
  public String toString() {
    StringBuilder string = new StringBuilder();

    if (this.basic.isGameOver()) {
      string.append("Game quit!\n");
      string.append("State of game when quit:\n");
      string.append("Draw: ");
      List<Card> draw = this.basic.getDrawCards();
      if (!draw.isEmpty()) {
        for (Card card : draw) {
          string.append(card.toString()).append(", ");
        }
        string.delete(string.length() - 2, string.length());
        string.append("\n");
      } else {
        string.append("<empty>\n");
      }
      string.append(renderFoundations(1, 1));
      string.append(renderCascades(this.basic, 1, 1));
      string.append("Score: ").append(this.basic.getScore()).append("\n");
    } else {
      string.append("Current game state:\n");
      string.append("Draw: ");
      List<Card> draw = this.basic.getDrawCards();
      if (!draw.isEmpty()) {
        for (Card card : draw) {
          string.append(card.toString()).append(", ");
        }
        string.delete(string.length() - 2, string.length());
        string.append("\n");
      } else {
        string.append("<empty>\n");
      }
      string.append(renderFoundations(1, 1));
      string.append(renderCascades(this.basic, 1, 1));
      string.append("Score: ").append(this.basic.getScore()).append("\n");
    }

    return string.toString();
  }

  private String renderFoundations(int cardNum, int pileNum) {
    if (cardNum < 1 || pileNum < 1) {
      throw new IllegalArgumentException("Invalid input.");
    }
    StringBuilder string = new StringBuilder();
    string.append("Foundation: ");
    int numFoundations = this.basic.getNumFoundations();
    for (int i = 0; i < numFoundations; i++) {
      Card top = this.basic.getCardAt(i);
      if (top == null || !top.isCardVisible(cardNum, pileNum)) {
        string.append("<none>");
      } else {
        string.append(top);
      }
      if (i < numFoundations - 1) {
        string.append(", ");
      }
    }
    string.append("\n");

    return string.toString();
  }

  public String render() {
    return toString();
  }

  /**
   * Renders cascade piles
   * for the view.
   */
  public String renderCascades(KlondikeModel basic, int cardNum, int pileNum) {
    if (cardNum < 0 || pileNum < 0) {
      throw new IllegalArgumentException("Invalid inputs.");
    }

    int numRows = this.basic.getNumRows();
    int numPiles = this.basic.getNumPiles();
    int maxCardLength = 3;
    StringBuilder result = new StringBuilder();

    for (int i = 0; i < numRows; i++) {
      for (int j = 0; j < numPiles; j++) {
        Card card = this.basic.getCardAt(j, i);
        if (card == null) {
          result.append("    ");
        } else {
          if (card.isCardVisible(cardNum, pileNum)) {
            String cardString = card.toString();
            result.append(cardString);
            int spacing = maxCardLength - cardString.length();
            if (spacing < 0) {
              spacing = 1;
            }
            for (int k = 0; k < spacing; k++) {
              result.append(" ");
            }
          } else {
            result.append(" ?  ");
          }
        }
      }
      result.append("\n");
    }
    return result.toString();
  }

}


