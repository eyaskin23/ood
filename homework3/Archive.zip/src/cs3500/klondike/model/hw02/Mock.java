package cs3500.klondike.model.hw02;

import java.util.ArrayList;
import java.util.List;

/**
 * Creates a mock class for the controler to use.
 */
public class Mock implements KlondikeModel {

  StringBuilder log;

  public Mock(StringBuilder log) {
    this.log = new StringBuilder();
  }

  /**
   * creates a deck for the mock.
   */
  public List<Card> getDeck() {
    List<Card> custom = new ArrayList<>();
    for (Suit suit : Suit.values()) {
      for (int i = 1; i <= 13; i++) {
        custom.add(new CardImpl(Rank.values()[i - 1], suit));
      }
    }
    return custom;
  }

  /**
   * Starts a game of mock.
   */
  public void startGame(List<Card> deck, boolean shuffle, int numPiles, int numDraw)
          throws IllegalArgumentException, IllegalStateException {
    //start game
  }

  @Override
  public void movePile(int srcPile, int numCards, int destPile)
          throws IllegalArgumentException, IllegalStateException {
    log.append("mpp").append(srcPile).append(numCards).append(destPile);
  }

  @Override
  public void moveDraw(int destPile) throws IllegalArgumentException, IllegalStateException {
    log.append("md").append(destPile);
  }

  @Override
  public void moveToFoundation(int srcPile, int foundationPile)
          throws IllegalArgumentException, IllegalStateException {
    log.append(String.format("srcPile"), srcPile, foundationPile);
  }

  @Override
  public void moveDrawToFoundation(int foundationPile)
          throws IllegalArgumentException, IllegalStateException {
    log.append("mdf").append(foundationPile).append(foundationPile);
  }

  @Override
  public void discardDraw() throws IllegalStateException {
    log.append("dd");
  }

  @Override
  public int getNumRows() throws IllegalStateException {
    return 0;
  }

  @Override
  public int getNumPiles() throws IllegalStateException {
    return 0;
  }

  @Override
  public int getNumDraw() throws IllegalStateException {
    return 0;
  }

  @Override
  public boolean isGameOver() throws IllegalStateException {
    return false;
  }

  @Override
  public int getScore() throws IllegalStateException {
    return 0;
  }

  @Override
  public int getPileHeight(int pileNum)
          throws IllegalArgumentException, IllegalStateException {
    return 0;
  }

  @Override
  public boolean isCardVisible(int pileNum, int card)
          throws IllegalArgumentException, IllegalStateException {
    return true;
  }

  @Override
  public Card getCardAt(int pileNum, int card)
          throws IllegalArgumentException, IllegalStateException {
    return null;
  }

  @Override
  public Card getCardAt(int foundationPile)
          throws IllegalArgumentException, IllegalStateException {
    return null;
  }

  @Override
  public List<Card> getDrawCards() throws IllegalStateException {
    return null;
  }

  @Override
  public int getNumFoundations() throws IllegalStateException {
    return 0;
  }
}
